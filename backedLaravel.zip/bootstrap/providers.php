<?php

return [
    App\Providers\AppServiceProvider::class,
    L5Swagger\L5SwaggerServiceProvider::class,
];
