<?php

return [
    'apps' => [
        [
            'id' => 'local',
            'name' => 'RFQ Negotiation System',
            'key' => 'local',
            'secret' => 'local',
            'path' => '/',
            'capacity' => null,
            'enable_client_messages' => true,
            'enable_statistics' => true,
        ],
    ],
];
